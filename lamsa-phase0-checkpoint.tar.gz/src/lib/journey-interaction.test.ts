// @vitest-environment jsdom
import { describe, it, expect, beforeAll, afterEach, vi } from "vitest";
import { act } from "react";
import { createRoot, type Root } from "react-dom/client";
import { createElement } from "react";
import { InvitationJourney } from "@/components/invitation/InvitationJourney";
import type { DesignDocument, DesignPage } from "./design";
import { CONTINUE_LABEL, HANDOFF_MS, OPEN_LABEL } from "./presentation";

beforeAll(() => {
  (globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true;
  if (!("ResizeObserver" in globalThis)) {
    class NoopResizeObserver {
      observe() {}
      unobserve() {}
      disconnect() {}
    }
    (globalThis as unknown as { ResizeObserver: unknown }).ResizeObserver =
      NoopResizeObserver;
  }
  // jsdom lays nothing out, so every element reports a zero box. Give them a
  // stage-sized one: the presentation measures its container to place the
  // invitation slot, and without a box there is no invitation to assert on.
  Object.defineProperty(HTMLElement.prototype, "clientWidth", {
    configurable: true,
    get: () => 900,
  });
  Object.defineProperty(HTMLElement.prototype, "clientHeight", {
    configurable: true,
    get: () => 600,
  });
});

let root: Root | null = null;
let host: HTMLDivElement | null = null;

afterEach(() => {
  if (root) act(() => root?.unmount());
  root = null;
  host?.remove();
  host = null;
  vi.useRealTimers();
});

function page(id: string, text: string): DesignPage {
  return {
    id,
    name: id,
    background: "#f2f1ed",
    elements: [
      {
        id: `${id}-text`,
        kind: "text",
        name: id,
        text,
        x: 100,
        y: 500,
        w: 800,
        h: 160,
        rotation: 0,
        opacity: 1,
        locked: false,
        hidden: false,
        font: "cormorant-garamond",
        fontSize: 72,
        color: "#161616",
        animation: {
          enabled: true,
          preset: "fade",
          trigger: "load",
          delay: 0,
          duration: 600,
          easing: "easeOut",
        },
      },
    ],
  };
}

function design(): DesignDocument {
  return {
    version: 1,
    pages: [page("Cover", "Amelia and Soren"), page("Venue", "The Garden Hall")],
    opening: { experience: "none", autoOpen: false, welcome: "" },
    closing: { enabled: true, style: "message", message: "With love, always", duration: 1200 },
    transition: { preset: "fade", duration: 600 },
  };
}

function mount(node: React.ReactElement) {
  host = document.createElement("div");
  document.body.appendChild(host);
  root = createRoot(host);
  act(() => root?.render(node));
  return host;
}

function buttonByText(container: HTMLElement, label: string) {
  return Array.from(container.querySelectorAll("button")).find((button) =>
    (button.textContent ?? "").trim().startsWith(label),
  );
}

function buttonByLabel(container: HTMLElement, label: string) {
  return Array.from(container.querySelectorAll("button")).find(
    (button) => button.getAttribute("aria-label") === label,
  );
}

describe("guest journey interaction", () => {
  it("reveals one section at a time and closes on the last one", () => {
    const container = mount(
      createElement(InvitationJourney, {
        design: design(),
        imageUrls: {},
        reducedMotion: true,
      }),
    );

    // Section one is present; section two has not been forced in yet.
    expect(container.textContent).toContain("Amelia and Soren");
    expect(container.textContent).not.toContain("The Garden Hall");

    const continueButton = buttonByText(container, "Continue");
    expect(continueButton).toBeTruthy();
    act(() => continueButton?.dispatchEvent(new MouseEvent("click", { bubbles: true })));

    expect(container.textContent).toContain("The Garden Hall");
    const closeButton = buttonByLabel(container, "Close the invitation");
    expect(closeButton).toBeTruthy();
    // The option to finish is stated in words, not an unlabelled glyph.
    expect(closeButton?.textContent).toContain("Close");

    act(() => closeButton?.dispatchEvent(new MouseEvent("click", { bubbles: true })));
    expect(container.textContent).toContain("With love, always");
    expect(buttonByText(container, "Continue")).toBeUndefined();
  });

  it("hands the guest the reference opening, then settles the first section", () => {
    vi.useFakeTimers();
    const queue: FrameRequestCallback[] = [];
    vi.stubGlobal("requestAnimationFrame", (callback: FrameRequestCallback) => {
      queue.push(callback);
      return queue.length;
    });
    vi.stubGlobal("cancelAnimationFrame", () => {});

    const withOpening = design();
    withOpening.opening = {
      experience: "cinematic",
      duration: 3200,
      autoOpen: false,
      welcome: "",
    };

    const container = mount(
      createElement(InvitationJourney, {
        design: withOpening,
        imageUrls: {},
        guestName: "Amara",
        reducedMotion: false,
      }),
    );

    // The presentation owns a real three-scene engine, so the guest is
    // handed the chosen scene's own opening cover, not a placeholder. A
    // retired experience falls back to the first scene, from its first frame.
    expect(container.querySelector("[data-testid=\"presentation-stage\"]"))
      .toBeTruthy();
    expect(container.querySelector("[data-scene]")?.getAttribute("data-scene"))
      .toBe("secret-world");
    expect(container.querySelector("[data-state]")?.getAttribute("data-state"))
      .toBe("pre");
    // The real first section sits exactly once, in the scene's invitation slot.
    const invitations = container.querySelectorAll("[data-testid=\"invitation\"]");
    expect(invitations.length).toBe(1);
    const slot = container.querySelector("[data-testid=\"invitation-slot\"]");
    expect(slot?.contains(invitations[0] as Node)).toBe(true);

    // The entrance plays, then the scene lands closed with the way in.
    act(() => {
      vi.advanceTimersByTime(80);
    });
    expect(container.querySelector("[data-state]")?.getAttribute("data-state"))
      .toBe("intro");
    act(() => {
      vi.advanceTimersByTime(20_000);
    });
    expect(container.querySelector("[data-state]")?.getAttribute("data-state"))
      .toBe("closed");

    const open = buttonByText(container, OPEN_LABEL);
    expect(open).toBeTruthy();
    act(() => open?.dispatchEvent(new MouseEvent("click", { bubbles: true })));
    expect(container.querySelector("[data-state]")?.getAttribute("data-state"))
      .toBe("opening");
    act(() => {
      vi.advanceTimersByTime(20_000);
    });
    expect(container.querySelector("[data-state]")?.getAttribute("data-state"))
      .toBe("revealed");

    const onward = buttonByText(container, CONTINUE_LABEL);
    expect(onward).toBeTruthy();
    act(() => onward?.dispatchEvent(new MouseEvent("click", { bubbles: true })));
    act(() => {
      vi.advanceTimersByTime(HANDOFF_MS);
    });

    // The opening has handed over to the same section, now a live page.
    expect(container.querySelector("[data-testid=\"presentation-stage\"]")).toBeNull();
    expect(container.textContent).toContain("Amelia and Soren");

    // The flourish returns once the section has settled.
    act(() => {
      vi.advanceTimersByTime(1000);
    });
    expect(buttonByLabel(container, "Continue to section 2 of 2")).toBeTruthy();

    vi.useRealTimers();
    vi.unstubAllGlobals();
  });

  it("offers an invitation-integrated flourish rather than a button plaque", () => {
    const container = mount(
      createElement(InvitationJourney, {
        design: design(),
        imageUrls: {},
        reducedMotion: true,
      }),
    );
    const cue = container.querySelector("[data-journey-cue]");
    expect(cue).toBeTruthy();
    // It is a real, named control with a drawn ornament, not a page picker.
    expect(cue?.tagName).toBe("BUTTON");
    expect(cue?.getAttribute("aria-label")).toBe("Continue to section 2 of 2");
    expect(cue?.querySelector("svg")).toBeTruthy();
    expect(container.querySelector("[aria-label^='Page ']")).toBeNull();
  });

  it("offers no transport controls to the guest", () => {
    const container = mount(
      createElement(InvitationJourney, {
        design: design(),
        imageUrls: {},
        reducedMotion: true,
      }),
    );
    const labels = Array.from(container.querySelectorAll("button")).map(
      (button) => `${button.getAttribute("aria-label") ?? ""} ${button.textContent ?? ""}`,
    );
    expect(labels.some((label) => /pause|resume|replay|previous section|next section/i.test(label))).toBe(false);
  });
});
