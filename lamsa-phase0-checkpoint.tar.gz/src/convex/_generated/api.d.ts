/* eslint-disable */
/**
 * Generated `api` utility.
 *
 * THIS CODE IS AUTOMATICALLY GENERATED.
 *
 * To regenerate, run `npx convex dev`.
 * @module
 */

import type * as auth from "../auth.js";
import type * as auth_emailOtp from "../auth/emailOtp.js";
import type * as http from "../http.js";
import type * as invitations from "../invitations.js";
import type * as lib_designAssets from "../lib/designAssets.js";
import type * as lib_pinCrypto from "../lib/pinCrypto.js";
import type * as library from "../library.js";
import type * as pin from "../pin.js";
import type * as pinProvider from "../pinProvider.js";
import type * as pinStore from "../pinStore.js";
import type * as studio from "../studio.js";
import type * as users from "../users.js";
import type * as validators from "../validators.js";

import type {
  ApiFromModules,
  FilterApi,
  FunctionReference,
} from "convex/server";

declare const fullApi: ApiFromModules<{
  auth: typeof auth;
  "auth/emailOtp": typeof auth_emailOtp;
  http: typeof http;
  invitations: typeof invitations;
  "lib/designAssets": typeof lib_designAssets;
  "lib/pinCrypto": typeof lib_pinCrypto;
  library: typeof library;
  pin: typeof pin;
  pinProvider: typeof pinProvider;
  pinStore: typeof pinStore;
  studio: typeof studio;
  users: typeof users;
  validators: typeof validators;
}>;

/**
 * A utility for referencing Convex functions in your app's public API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = api.myModule.myFunction;
 * ```
 */
export declare const api: FilterApi<
  typeof fullApi,
  FunctionReference<any, "public">
>;

/**
 * A utility for referencing Convex functions in your app's internal API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = internal.myModule.myFunction;
 * ```
 */
export declare const internal: FilterApi<
  typeof fullApi,
  FunctionReference<any, "internal">
>;

export declare const components: {};
